local mod_name = minetest.get_current_modname()
local mod_path = minetest.get_modpath(mod_name)

local spawn_pos = {x = -15, y = -20, z = -15} 

dofile(mod_path .. "/player/init.lua")
dofile(mod_path .. "/engine/init.lua")


local player_data = {}

function colocar_schematic(player,schem)
    local schem_path = minetest.get_modpath("one_of_us") .. "/schems/mapa.mts"
        minetest.place_schematic(
            spawn_pos,
            schem_path,
            0,  
            nil, 
            true 
        )
end

core.after(0, function()
    core.chat_send_all("¡Mapa mts de prueba!")
    colocar_schematic(player)
end)

