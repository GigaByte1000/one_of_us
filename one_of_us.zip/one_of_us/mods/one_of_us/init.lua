local mod_name = minetest.get_current_modname()
local mod_path = minetest.get_modpath(mod_name)

local spawn_pos = {x = -80, y = -20, z = -80} 

dofile(mod_path .. "/player/init.lua")
dofile(mod_path .. "/mundo/init.lua")

local player_data = {}
local fixlight_radius = 222

function colocar_schematic(player,schem)
    local schem_path = minetest.get_modpath("one_of_us") .. "/schems/mapa.mts"
        minetest.place_schematic(
            spawn_pos,
            schem_path,
            0,  
            nil, 
            true 
        )
end

core.after(0, function()
    colocar_schematic(player)
end)
