minetest.register_node("one_of_us:cesped", {
  description = "cesped",
  tiles = {"cesped.png"},
})
minetest.register_node("one_of_us:cesped_nieve", {
  description = "cesped_nieve",
  tiles = {"cesped_nieve.png"},
})
minetest.register_node("one_of_us:cesped_muerto", {
  description = "cesped_muerto",
  tiles = {"cesped_muerto.png"},
})
minetest.register_node("one_of_us:lampara", {
  description = "lampara",
  tiles = {"lampara.png"},
  paramtype = "light",
  light_source = core.LIGHT_MAX,
})

minetest.register_node("one_of_us:ladrillo", {
  description = "ladrillo",
  tiles = {"ladrillo.png"},
})
minetest.register_node("one_of_us:pino", {
  description = "pino",
  tiles = {"pino.png"},
})
minetest.register_node("one_of_us:madera_pino", {
  description = "madera_pino",
  tiles = {"madera_pino.png"},
})
minetest.register_node("one_of_us:hoja_pino", {
  description = "hoja_pino",
  tiles = {"hoja_pino.png"},
})
minetest.register_node("one_of_us:acacia", {
  description = "acacia",
  tiles = {"acacia.png"},
})
minetest.register_node("one_of_us:acacia_madera", {
  description = "acacia_madera",
  tiles = {"acacia_madera.png"},
})
minetest.register_node("one_of_us:acacia_hoja", {
  description = "acacia_hoja",
  tiles = {"acacia_hoja.png"},
})
minetest.register_node("one_of_us:cactus", {
  description = "cactus",
  tiles = {"cactus.png"},
})
minetest.register_node("one_of_us:libreria", {
  description = "libreria",
  tiles = {"libreria.png"},
})
minetest.register_node("one_of_us:grava", {
  description = "grava",
  tiles = {"grava.png"},
})
minetest.register_node("one_of_us:hielo", {
  description = "hielo",
  tiles = {"hielo.png"},
})
minetest.register_node("one_of_us:jungla", {
  description = "jungla",
  tiles = {"jungla.png"},
})
minetest.register_node("one_of_us:jungla_madera", {
  description = "jungla_madera",
  tiles = {"jungla_madera.png"},
})
minetest.register_node("one_of_us:hoja_jungla", {
  description = "hoja_jungla",
  tiles = {"hoja_jungla.png"},
})

minetest.register_node("one_of_us:black_concrete", {
  description = "black_concrete",
  tiles = {"black_concrete.png"},
})

minetest.register_node("one_of_us:blue_concrete", {
  description = "blue_concrete",
  tiles = {"blue_concrete.png"},
})
minetest.register_node("one_of_us:brown_concrete", {
  description = "brown_concrete",
  tiles = {"brown_concrete.png"},
})
minetest.register_node("one_of_us:cyan_concrete", {
  description = "cyan_concrete",
  tiles = {"cyan_concrete.png"},
})
minetest.register_node("one_of_us:gray_concrete", {
  description = "gray_concrete",
  tiles = {"gray_concrete.png"},
})
minetest.register_node("one_of_us:green_concrete", {
  description = "green_concrete",
  tiles = {"green_concrete.png"},
})
minetest.register_node("one_of_us:light_blue_concrete", {
  description = "light_blue_concrete",
  tiles = {"light_blue_concrete.png"},
})
minetest.register_node("one_of_us:light_gray_concrete", {
  description = "light_gray_concrete",
  tiles = {"light_gray_concrete.png"},
})
minetest.register_node("one_of_us:lime_concrete", {
  description = "lime_concrete",
  tiles = {"lime_concrete.png"},
})
minetest.register_node("one_of_us:magenta_concrete", {
  description = "magenta_concrete",
  tiles = {"magenta_concrete.png"},
})
minetest.register_node("one_of_us:orange_concrete", {
  description = "orange_concrete",
  tiles = {"orange_concrete.png"},
})
minetest.register_node("one_of_us:pink_concrete", {
  description = "pink_concrete",
  tiles = {"pink_concrete.png"},
})
minetest.register_node("one_of_us:purple_concrete", {
  description = "purple_concrete",
  tiles = {"purple_concrete.png"},
})
minetest.register_node("one_of_us:yellow_concrete", {
  description = "yellow_concrete",
  tiles = {"yellow_concrete.png"},
})
minetest.register_node("one_of_us:red_concrete", {
  description = "red_concrete",
  tiles = {"red_concrete.png"},
})
minetest.register_node("one_of_us:white_concrete", {
  description = "white_concrete",
  tiles = {"white_concrete.png"},
})