local impostores = {}
local jugadores_activos = {}
local juego_iniciado = false
local juego_activo = false
local mod_name = core.get_current_modname()
local mod_path = core.get_modpath(mod_name)
local cooldown_ataque = {} 
local votaciones_activas = false
local votos = {}
local tiempo_votacion = 60
local TIEMPO_LIMITE = 360
local PAUSA_REINICIO = 3
local tiempo_restante = TIEMPO_LIMITE
local jugadores_esperando = {} 
local temporizador_global = nil
local cooldown = 120
local last_used = {}

function impostor(player)
    local name = player:get_player_name()
    score_hud_id = player:hud_add({
        type = "image",
        name = "custom_cursor_" .. name,
        text = "impostor.png",
        scale = {x=0.6, y=0.6},
        alignment = {x=0, y=0},
        offset = {x=50, y=50},
        position = {x = 0.43, y = 0.47},
    })
    minetest.after(3, function()
         player:hud_remove(score_hud_id)
    end)
end
function trabajador(player)
    local name = player:get_player_name()
    score_hud_id = player:hud_add({
        type = "image",
        name = "custom_cursor_" .. name,
        text = "worker.png",
        scale = {x=0.6, y=0.6},
        alignment = {x=0, y=0},
        offset = {x=50, y=50},
        position = {x = 0.48, y = 0.47},
    })
    minetest.after(3, function()
         player:hud_remove(score_hud_id)
    end)
end

local function contar_impostores_vivos()
    local count = 0
    for name, is_impostor in pairs(impostores) do
        if is_impostor and jugadores_activos[name] then
            count = count + 1
        end
    end
    return count
end

local function contar_trabajadores_vivos()
    local count = 0
    for name, is_impostor in pairs(impostores) do
        if not is_impostor and jugadores_activos[name] then
            count = count + 1
        end
    end
    return count
end

function verificar_estado_juego()

    if not juego_activo then return end

    local impostores_vivos = contar_impostores_vivos()
    local trabajadores_vivos = contar_trabajadores_vivos()

    if impostores_vivos <= 0 then
        juego_activo = false
        core.chat_send_all("¡Todos los impostores eliminados! Los trabajadores ganan.")
        if temporizador_global then
            core.after(0, function() core.unregister_globalstep(temporizador_global) end)
            temporizador_global = nil 
        end
        core.after(PAUSA_REINICIO, function()
            reiniciar_juego()
        end)
        return
    end

    if trabajadores_vivos <= impostores_vivos then 
        juego_activo = false
        core.chat_send_all("¡Los impostores superan en número a los trabajadores! Los impostores ganan.")
        if temporizador_global then

            core.after(0, function() core.unregister_globalstep(temporizador_global) end)
             temporizador_global = nil 
        end

        core.after(PAUSA_REINICIO, function()
            reiniciar_juego()
        end)
        return
    end


    if tiempo_restante <= 0 and juego_activo then 
         juego_activo = false 
         core.chat_send_all("¡Tiempo agotado! Los impostores ganan.")
         if temporizador_global then
            core.after(0, function() core.unregister_globalstep(temporizador_global) end)
             temporizador_global = nil
        end
         core.after(PAUSA_REINICIO, function()
            reiniciar_juego()
        end)
         return
    end

end

function reiniciar_juego()
    core.chat_send_all("Engine: Restarting Game!...")
    impostores = {}
    jugadores_activos = {}
    tiempo_restante = TIEMPO_LIMITE
    juego_iniciado = false
    juego_activo = true
    votaciones_activas = false
    votos = {}
    last_used = {}

    if temporizador_global then
         core.unregister_globalstep(temporizador_global)
         temporizador_global = nil
    end

    local players_for_next_game = {}

    for _, player in ipairs(core.get_connected_players()) do
        local name = player:get_player_name()

        player:set_properties({visual_size = {x = 1, y = 1}})
        player:set_physics_override({speed = 1,
                                    jump = 1,
                                    gravity = 1
        })
        local pos = {x = -5, y = -15, z = -5}
        player:set_pos(pos)

        table.insert(players_for_next_game, player)

        if jugadores_esperando[name] then
            jugadores_esperando[name] = nil
        end
    end

    jugadores_esperando = {}

    asignar_roles(players_for_next_game)
end

core.register_on_leaveplayer(function(player)
    local name = player:get_player_name()
    if jugadores_esperando[name] then
        jugadores_esperando[name] = nil
    end

    if jugadores_activos[name] then
        jugadores_activos[name] = false
        verificar_estado_juego() 
    end
end)

function asignar_roles(players_to_assign)
    if juego_iniciado then
         core.chat_send_all("El juego ya comenzo. Debes esperar a que termine.")
         return
     end

    local players = players_to_assign or core.get_connected_players() 
         juego_iniciado = false 
         juego_activo = false

    juego_iniciado = true
    juego_activo = true

    local num_impostores = math.min(3, math.max(1, math.ceil(#players / 4)))

    local candidates = {}
    for _, player in ipairs(players) do
        table.insert(candidates, player:get_player_name())
    end

    impostores = {}
    jugadores_activos = {}

    for i = #candidates, 2, -1 do
        local j = math.random(i)
        candidates[i], candidates[j] = candidates[j], candidates[i]
    end

    for i = 1, num_impostores do
        local name = candidates[i]
        impostores[name] = true
        jugadores_activos[name] = true 
        local player = core.get_player_by_name(name)
        if player then
             core.chat_send_player(name, "You are an IMPOSTER.")
             impostor(player)
             player:set_pos({x = -5, y = -15, z = -5})
        end
    end

    for i = num_impostores+1, #candidates do
        local name = candidates[i]
        impostores[name] = false
        jugadores_activos[name] = true
         local player = core.get_player_by_name(name)
        if player then
             core.chat_send_player(name, "You are hardworking, do the tasks to earn")
             trabajador(player)
             player:set_pos({x = -5, y = -15, z = -5})
        end
    end

    tiempo_restante = TIEMPO_LIMITE
    if temporizador_global then
         core.unregister_globalstep(temporizador_global)
         temporizador_global = nil
    end

    temporizador_global = core.register_globalstep(function(dtime)
        if juego_activo and not votaciones_activas then
            tiempo_restante = tiempo_restante - dtime
            if tiempo_restante <= 0 then
                tiempo_restante = 0 
                verificar_estado_juego()
            end
        end
    end)
end

core.register_on_joinplayer(function(player)
    local name = player:get_player_name()
    if juego_activo then
        core.chat_send_player(name, "El juego está en curso. Unete a la siguiente ronda.")
        convertir_en_fanstasma(player)
        jugadores_esperando[name] = true 
        jugadores_activos[name] = false
        impostores[name] = nil 
        return
    end
end)

local function mostrar_formspec_votacion(player,iniciador)
    local pname = player:get_player_name()
    if not jugadores_activos[pname] then
        return
    end

    local formspec = {
        "size[13,9]",
        "label[5,0;EMERGENCY MEETING]",
        "label[5,1;select a suspicious player:]",
        "box[-0.1,0;13,9;#9b9b9b]",
        "box[0.5,1.5;12,7;#000000]",
        "button_exit[5,8.5;2,1;;finish]"
    }

    local y_pos = 2.0

    for name, activo in pairs(jugadores_activos) do
        if activo and name ~= pname then
            table.insert(formspec, "button[0.5,"..y_pos..";2,1;votar_"..name..";"..name.."]")
            y_pos = y_pos + 1.1
        end
    end

    table.insert(formspec, "button[0.5,8.5;2,1;votar_skip;do not vote]")
    table.insert(formspec, "label[6,0.5;started by:"..iniciador.."]")
    table.insert(formspec, "label[8,8.5;time to vote: "..tiempo_votacion.." seconds]")

    core.show_formspec(pname, "one_of_us:votacion_emergencia", table.concat(formspec, ""))
end

local function iniciar_votacion_emergencia(iniciador)
    if votaciones_activas then
        core.chat_send_player(iniciador, "⚠ Ya hay una votación en curso")
        return
    end

    if not juego_activo then
        core.chat_send_player(iniciador, "⚠ No se puede iniciar votación - juego no activo")
        return
    end


    if not jugadores_activos[iniciador] then
        core.chat_send_player(iniciador, "⚠ Solo los jugadores activos pueden iniciar una reunión.")
        return
    end

    votaciones_activas = true
    votos = {} 

    core.chat_send_all("¡REUNIÓN DE EMERGENCIA! Iniciada por "..iniciador)

    local active_players_count = 0
    for name, activo in pairs(jugadores_activos) do
        if activo then
            active_players_count = active_players_count + 1
            local player = core.get_player_by_name(name)
            if player then

                 core.close_formspec(name, "one_of_us:votacion_emergencia")
                 core.close_formspec(name, "one_of_us:RESULTADOS")
                mostrar_formspec_votacion(player, iniciador)
            end
        end
    end

    if active_players_count < 2 then
        core.chat_send_all("No hay suficientes jugadores activos para votar. La votación termina.")
        votaciones_activas = false
        votos = {}

        if temporizador_global then

        end
        return
    end

    local tiempo_restante_votacion = tiempo_votacion

    local voting_timer_handle = core.register_globalstep(function(dtime)
        if votaciones_activas then 
            tiempo_restante_votacion = tiempo_restante_votacion - dtime

   

            if tiempo_restante_votacion <= 0 then
                tiempo_restante_votacion = 0 

                one_of_us()

                if voting_timer_handle then
                     core.unregister_globalstep(voting_timer_handle)
                     voting_timer_handle = nil 
                end
                return
            end
        else

             if voting_timer_handle then
                core.unregister_globalstep(voting_timer_handle)
                voting_timer_handle = nil 
             end
        end
    end)

end

core.register_on_player_receive_fields(function(player, formname, fields)

    if not votaciones_activas or formname ~= "one_of_us:votacion_emergencia" then
        return false 
    end

    local pname = player:get_player_name()

     if not jugadores_activos[pname] then
        core.chat_send_player(pname, "No eres un jugador activo y no puedes votar.")
        core.close_formspec(pname, "one_of_us:votacion_emergencia") 
        return false
     end

    if votos[pname] then
        core.chat_send_player(pname, "¡Ya has votado!")
        return true
    end

    for field, _ in pairs(fields) do
        if field:sub(1, 6) == "votar_" then
            local votado = field:sub(7)
            if votado == "skip" then
                votos[pname] = "skip"
                core.chat_send_player(pname, "Decidiste no votar")
                 core.close_formspec(pname, "one_of_us:votacion_emergencia") 
            else

                if jugadores_activos[votado] then
                    votos[pname] = votado
                    core.chat_send_player(pname, "Votaste por: "..votado)
                     core.close_formspec(pname, "one_of_us:votacion_emergencia") 
                else
                     core.chat_send_player(pname, "Ese jugador no está activo o no existe.")
                     return false 
                end
            end

            local active_voters_count = 0
            for name, activo in pairs(jugadores_activos) do
                if activo then
                    active_voters_count = active_voters_count + 1
                end
            end
            local votes_count = 0
            for voter, _ in pairs(votos) do
                votes_count = votes_count + 1
            end

            if votes_count >= active_voters_count then
                 core.chat_send_all("Todos los jugadores han votado. Terminando votación anticipadamente.")
                 one_of_us()
            end

            return true
        end
    end

    if fields.finish then

         core.chat_send_player(pname, "Cerraste el menú de votación sin votar.")

         return true 
    end

    return false 
end)

function convertir_en_fanstasma(player)
    if player then 

        player:set_pos({x = -5, y = -15, z = -5})

        player:set_properties({visual_size = {x = 0, y = 0}})

        player:set_physics_override({speed = 5,
                                    jump = 0,
                                    gravity = 0
        })

    end
end

function resultados(mas_votado, max_votos, sin_expulsiones, impostor)

    local result_message_line1 = ""
    local result_message_line2 = "" 

    if sin_expulsiones == false then
        result_message_line1 = "was expelled: "..mas_votado.." with "..max_votos.." votes"
    else
        result_message_line1 = "no one is expelled (omission or tie)"
    end

    if sin_expulsiones == false and impostor ~= nil then 
         if impostor then
            result_message_line2 = "he was the imposter"
         else
            result_message_line2 = "he was not the imposter"
         end
    end


    for _, player in ipairs(core.get_connected_players()) do
        local nombre = player:get_player_name()

        core.after(2, function()
            local p = core.get_player_by_name(nombre)
            if p then
                 local formspec = {
                    "size[13,9]",
                    "label[5.5,0;VOTING RESULTS]",
                    "box[0.5,1.5;12,7;#000000]",
                    "box[-0.1,0;13,9;#9b9b9b]",
                    "button_exit[5.5,8.5;2,1;;finish]"
                 }

                 table.insert(formspec, "label[5,5;"..result_message_line1.."]")
                 if result_message_line2 ~= "" then
                     table.insert(formspec, "label[5,6;"..result_message_line2.."]")
                 end

                 core.show_formspec(nombre, "one_of_us:RESULTADOS", table.concat(formspec, ""))
            end
        end)
    end
end


function one_of_us()

    if not votaciones_activas then return end


    votaciones_activas = false

    core.chat_send_all("¡Resultados de la votación!")


     for _, player in ipairs(core.get_connected_players()) do
        local name = player:get_player_name()
        core.close_formspec(name, "one_of_us:votacion_emergencia")
     end



    local conteo = {}
    local skip_votes = 0
    for voter, votado in pairs(votos) do
        if votado == "skip" then
            skip_votes = skip_votes + 1
        else

             if jugadores_activos[votado] then
                conteo[votado] = (conteo[votado] or 0) + 1
             end
        end
    end

    local mas_votado = nil
    local max_votos = 0
    local tie = false 

    for jugador, cantidad in pairs(conteo) do
        if cantidad > max_votos then
            max_votos = cantidad
            mas_votado = jugador
            tie = false 
        elseif cantidad == max_votos and cantidad > 0 then
            tie = true 
        end
    end

    local expelled_player = nil
    local sin_expulsiones = true
    local is_expelled_impostor = nil 

    if mas_votado and not tie then 
        expelled_player = mas_votado
        sin_expulsiones = false

        if jugadores_activos[expelled_player] then
            jugadores_activos[expelled_player] = false
            local player = core.get_player_by_name(expelled_player)
            if player then
                convertir_en_fanstasma(player)
            end

            is_expelled_impostor = impostores[expelled_player] == true
        end
    end

    resultados(expelled_player, max_votos, sin_expulsiones, is_expelled_impostor)

    verificar_estado_juego()

end


core.register_node("one_of_us:tarea_boton", {
    description = "Tarea: Activar Boton",
    tiles = {"one_of_us_boton.png"},
    on_rightclick = function(pos, node, player)
        local name = player:get_player_name()
        if not juego_activo then
            core.chat_send_player(name, "El juego no está activo ahora mismo")
            return
        end

        if not jugadores_activos[name] then
            core.chat_send_player(name, "No eres un jugador activo y no puedes hacer tareas.")
            return
        end

        if impostores[name] then
            core.chat_send_player(name, "¡Los impostores no pueden hacer tareas!")
        else
            core.chat_send_player(name, "✅ Tarea completada!")

        end
    end,
})


core.register_node("one_of_us:boton_emergencia", {
    description = "Botón de Emergencia",
    tiles = {"button_emergency.png"},
    on_rightclick = function(pos, node, clicker)
        local name = clicker:get_player_name()
        local current_time = os.time()

        if not juego_activo then
            core.chat_send_player(name, "⚠ El juego no está activo ahora mismo")
            return
        end


        if not jugadores_activos[name] then
            core.chat_send_player(name, "⚠ No eres un jugador activo y no puedes usar este botón.")
            return
        end

        if last_used[name] and (current_time - last_used[name] < cooldown) then
            local remaining = cooldown - (current_time - last_used[name])
            core.chat_send_player(name, "⏳ Espera " .. remaining .. " segundos antes de volver a usar el botón.")
            return
        end

        iniciar_votacion_emergencia(name)
        last_used[name] = current_time 
    end,
})

core.register_chatcommand("start", {
    description = "Inicia el juego Among Us (solo una vez por partida)",
    privs = {server = true},
    func = function(name)

        local connected_players = core.get_connected_players()
        asignar_roles(connected_players)
    end,
})


core.register_chatcommand("reset", {
    description = "Reinicia completamente el juego",
    privs = {server = true},
    func = function(name)
        reiniciar_juego()
    end,
})


if PAUSA_REINICIO == nil then
    local PAUSA_REINICIO = 3
end